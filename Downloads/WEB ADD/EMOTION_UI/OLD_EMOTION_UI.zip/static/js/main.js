const video = document.getElementById('video');
const audio = document.getElementById('bg-music');

// Start camera
navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => {
    video.srcObject = stream;
  }).catch(err => console.error("Camera Error:", err));

// Load models from CDN
Promise.all([
  faceapi.nets.tinyFaceDetector.loadFromUri('/static/models/tiny_face_detector_model'),
  faceapi.nets.faceExpressionNet.loadFromUri('/static/models/face_expression_model')
]).then(startDetection);

function startDetection() {
  setInterval(async () => {
    
    const result = await faceapi.detectSingleFace(video, new faceapi.TinyFaceDetectorOptions()).withFaceExpressions();
    if (!result) return;

    const mood = getDominantExpression(result.expressions);
    console.log('Detected Mood:', mood);
    updateUI(mood);
  }, 1500);
}

function getDominantExpression(expressions) {
  return Object.entries(expressions).reduce((max, curr) => curr[1] > max[1] ? curr : max)[0];
}

function updateUI(mood) {
  const moodMap = {
    happy:    { color: '#ffe600', font: 'Comic Sans MS', music: 'happy.mp3' },
    sad:      { color: '#001f3f', font: 'Georgia',        music: 'sad.mp3' },
    angry:    { color: '#ff4136', font: 'Impact',         music: 'angry.mp3' },
    surprised:{ color: '#7fdbff', font: 'Cursive',        music: 'surprised.mp3' }
  };

  const config = moodMap[mood] || { color: '#ffffff', font: 'Arial', music: '' };

  document.body.style.backgroundColor = config.color;
  document.body.style.fontFamily = config.font;

  if (config.music && audio.src.indexOf(config.music) === -1) {
    audio.src = `/static/music/${config.music}`;
    audio.play();
  }
}
